// src/admin/pages/AdminPostEditorPage/AdminPostEditorPage.tsx
import PostEditorPage from '@/admin/editor/postEditor/PostEditorPage';

export default function AdminPostEditorPage() {
  return <PostEditorPage />;
}
