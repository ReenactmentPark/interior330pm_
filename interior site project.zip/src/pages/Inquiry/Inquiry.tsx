export default function Inquiry() {
    return (<></>)
}