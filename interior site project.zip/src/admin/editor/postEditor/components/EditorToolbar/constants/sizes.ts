export const SIZE_OPTIONS: number[] = [11, 13, 15, 16, 19, 24, 28, 30, 34, 38];
