import * as React from 'react';
import styles from '../EditorToolbar.module.css';
import { loadFontOnce } from '@/utils/fontLoader';
import { FONT_OPTIONS, FONT_DEFS, fontCssToLabel, familyToCss } from '../constants/fonts';

type Props = {
  current: string;
  onMouseDownItem: (e: React.MouseEvent<Element>) => void;
  onPick: (label: (typeof FONT_OPTIONS)[number]) => void;
};

export default function FontMenu({ current, onMouseDownItem, onPick }: Props) {
  const currentLabel = fontCssToLabel(current);

  // ✅ 메뉴 열릴 때 미리 로드(프리뷰용)
  React.useEffect(() => {
    void Promise.all(
      FONT_OPTIONS.map(async (label) => {
        const def = FONT_DEFS[label];
        if (!def?.srcUrl || def.family === 'inherit') return;
        await loadFontOnce({
          family: def.family,
          srcUrl: def.srcUrl,
          descriptors: { style: 'normal', weight: '400' },
        });
      })
    );
  }, []);

  return (
    <div className={styles.menuList}>
      {FONT_OPTIONS.map((label) => {
        const active = currentLabel === label;
        const def = FONT_DEFS[label];
        const previewCss = def?.family === 'inherit' ? 'inherit' : familyToCss(def?.family ?? '');

        return (
          <button
            key={label}
            type="button"
            className={styles.menuItem}
            onMouseDown={onMouseDownItem}
            onClick={() => onPick(label)}
          >
            <span className={styles.check}>{active ? '✓' : ''}</span>

            {/* ✅ 항목 텍스트가 해당 폰트로 보이게 */}
            <span className={styles.itemText} style={{ fontFamily: previewCss }}>
              {label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
