import * as React from 'react';
import styles from '../EditorToolbar.module.css';
import { FONT_OPTIONS, fontCssToLabel } from '../constants/fonts';

type Props = {
  // EditorToolbar에서 내려오는 값: 현재 selection의 font-family css 문자열일 수 있음
  current: string;
  onMouseDownItem: (e: React.MouseEvent<Element>) => void;
  // ✅ 이제 "라벨"을 그대로 올림
  onPick: (label: (typeof FONT_OPTIONS)[number]) => void;
};

export default function FontMenu({ current, onMouseDownItem, onPick }: Props) {
  const currentLabel = fontCssToLabel(current);

  return (
    <div className={styles.menuList}>
      {FONT_OPTIONS.map((label) => {
        const active = currentLabel === label;
        return (
          <button
            key={label}
            type="button"
            className={styles.menuItem}
            onMouseDown={onMouseDownItem}
            onClick={() => onPick(label)}
          >
            <span className={styles.check}>{active ? '✓' : ''}</span>
            <span className={styles.itemText}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}
